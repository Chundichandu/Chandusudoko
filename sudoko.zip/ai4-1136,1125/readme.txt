#### Running the code ####

1.open terminal at lab4_1125_1136
2.run command 'python3 ai4.py p.txt'